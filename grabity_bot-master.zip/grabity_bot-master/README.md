# grabity_bot
Un Bot diseñado para la entrega final del PC para la asignatura Estructuras Discretas. Pregrado de Ing. de Sistemas, Universidad del Norte

Con el, puedes ver distintas constelaciones almacenadas en archivos de texto en la carpeta del proyecto
